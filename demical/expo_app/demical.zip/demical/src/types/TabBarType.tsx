export type TabBarType = {
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
};
