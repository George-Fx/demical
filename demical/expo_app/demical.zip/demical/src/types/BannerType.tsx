export type BannerType = {
  id: number;
  title: string;
  title1: string;
  title2: string;
  image: string;
  btnText: string;
  description1: string;
  description2: string;
};
