export type PromocodeType = {
  id: number;
  name: string;
  discount: number;
  code: string;
  image: string;
  expires_at: string;
};
