import {View, Text} from 'react-native';
import React from 'react';

const Order = () => {
  return (
    <View>
      <Text>Order</Text>
    </View>
  );
};

export default Order;
