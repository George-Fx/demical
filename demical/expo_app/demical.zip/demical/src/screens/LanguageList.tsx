import {View, Text} from 'react-native';
import React from 'react';

const LanguageList: React.FC = () => {
  return (
    <View>
      <Text>LanguageList</Text>
    </View>
  );
};

export default LanguageList;
