import {View, Text} from 'react-native';
import React from 'react';

const BestSellerItem = () => {
  return (
    <View>
      <Text>BestSellerItem</Text>
    </View>
  );
};

export default BestSellerItem;
