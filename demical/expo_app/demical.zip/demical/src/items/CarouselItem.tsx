import {View, Text} from 'react-native';
import React from 'react';

const CarouselItem = () => {
  return (
    <View>
      <Text>CarouselItem</Text>
    </View>
  );
};

export default CarouselItem;
