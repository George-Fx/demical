import {View, Text} from 'react-native';
import React from 'react';

const PastAppointment: React.FC = () => {
  return (
    <View>
      <Text>PastAppointment</Text>
    </View>
  );
};

export default PastAppointment;
