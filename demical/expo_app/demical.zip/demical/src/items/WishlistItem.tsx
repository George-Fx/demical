import {View, Text} from 'react-native';
import React from 'react';

const WishlistItem = () => {
  return (
    <View>
      <Text>WishlistItem</Text>
    </View>
  );
};

export default WishlistItem;
