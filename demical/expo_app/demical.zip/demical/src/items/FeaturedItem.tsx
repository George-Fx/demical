import {View, Text} from 'react-native';
import React from 'react';

const FeaturedItem = () => {
  return (
    <View>
      <Text>FeaturedItem</Text>
    </View>
  );
};

export default FeaturedItem;
