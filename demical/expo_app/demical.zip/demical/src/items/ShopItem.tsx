import {View, Text} from 'react-native';
import React from 'react';

const ShopItem = () => {
  return (
    <View>
      <Text>ShopItem</Text>
    </View>
  );
};

export default ShopItem;
