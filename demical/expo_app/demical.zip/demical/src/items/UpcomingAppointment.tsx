import {View, Text} from 'react-native';
import React from 'react';

const UpcomingAppointment: React.FC = () => {
  return (
    <View>
      <Text>UpcomingAppointment</Text>
    </View>
  );
};

export default UpcomingAppointment;
